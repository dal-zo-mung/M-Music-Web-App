# M-Music chord core

Shared, dependency-free chart contracts, parser, validation, Unicode boundary helpers and transposition for the server, admin, web and mobile apps.

Author chords before text: `[C]First phrase [G7]ending`. Use `{section: Chorus}`, blank lines, chord-only instrumental lines, and `[N.C.]`. Escape literal brackets, braces and backslashes with a backslash. Original key is supplied separately. Supported chords include major/minor, diminished/augmented, suspensions, extensions, alterations and slash bass. Unsupported syntax is rejected rather than discarded.

Run `bun install`, `bun run build`, and `bun test`. From the family root, run `bun scripts/package-chord-core.ts` to build and distribute the same tarball to all consumers. Increment the version before distributing a changed release. Consumers depend on their own committed vendor archive, never on parent-folder source files.
